import "./assets/css/taildwind.css";
import "./App.css";

import Home from "./pages/Home";
import ValidateForm from "./components/ValidateForm";
import Validate from "./components/Validate";



const attri = {
  background:'red',
  color:'black'
}

function App() {


  return (
    <>
      {/* <Todolist/> */}
      {/* <Home/> */}
      {/* <ValidateForm/> */}
      <Validate />
    </>
  );
}

export default App;
